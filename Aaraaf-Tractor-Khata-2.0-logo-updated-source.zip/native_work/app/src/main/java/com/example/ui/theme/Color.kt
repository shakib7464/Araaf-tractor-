package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - Warm Ivory Paper & Deep Agricultural Emerald + Harvest Amber
val EmeraldPrimary = Color(0xFF1B4332)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD1FAE5)
val EmeraldOnPrimaryContainer = Color(0xFF064E3B)

val AmberSecondary = Color(0xFFD97706)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFFEF3C7)
val AmberOnSecondaryContainer = Color(0xFF78350F)

val TealTertiary = Color(0xFF0F766E)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealTertiaryContainer = Color(0xFFCCFBF1)
val TealOnTertiaryContainer = Color(0xFF134E4A)

val WarmBackgroundLight = Color(0xFFFAF8F3)
val WarmSurfaceLight = Color(0xFFFFFFFF)
val WarmSurfaceVariantLight = Color(0xFFF0EDE4)
val WarmOutlineLight = Color(0xFFD6D0C4)
val TextPrimaryLight = Color(0xFF1A1F1C)
val TextSecondaryLight = Color(0xFF525E57)

// Dark Palette - Deep Pine Charcoal & Luminous Emerald/Amber
val EmeraldPrimaryDark = Color(0xFF6EE7B7)
val EmeraldOnPrimaryDark = Color(0xFF022C22)
val EmeraldPrimaryContainerDark = Color(0xFF065F46)
val EmeraldOnPrimaryContainerDark = Color(0xFFD1FAE5)

val AmberSecondaryDark = Color(0xFFFBBF24)
val AmberOnSecondaryDark = Color(0xFF451A03)
val AmberSecondaryContainerDark = Color(0xFF92400E)
val AmberOnSecondaryContainerDark = Color(0xFFFEF3C7)

val TealTertiaryDark = Color(0xFF5EEAD4)
val TealOnTertiaryDark = Color(0xFF042F2E)
val TealTertiaryContainerDark = Color(0xFF115E59)
val TealOnTertiaryContainerDark = Color(0xFFCCFBF1)

val PineBackgroundDark = Color(0xFF0F1713)
val PineSurfaceDark = Color(0xFF17221D)
val PineSurfaceVariantDark = Color(0xFF213029)
val PineOutlineDark = Color(0xFF33473D)
val TextPrimaryDark = Color(0xFFECF3EE)
val TextSecondaryDark = Color(0xFFA7B8AE)

// Semantic Ledger Tokens
val DueCrimsonLight = Color(0xFFC62828)
val DueCrimsonDark = Color(0xFFEF5350)
val PaidEmeraldLight = Color(0xFF1B5E20)
val PaidEmeraldDark = Color(0xFF66BB6A)
val AdvanceBlueLight = Color(0xFF0277BD)
val AdvanceBlueDark = Color(0xFF4FC3F7)
