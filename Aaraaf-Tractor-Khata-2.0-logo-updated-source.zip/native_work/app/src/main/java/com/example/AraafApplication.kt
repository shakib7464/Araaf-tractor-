package com.example

import android.app.Application
import com.example.data.backup.BackupRepository
import com.example.data.local.AraafDatabase
import com.example.data.preferences.AppPreferencesManager
import com.example.data.repository.KhataRepository
import com.example.export.PdfGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AraafApplication : Application() {
  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  val database: AraafDatabase by lazy { AraafDatabase.getInstance(this) }
  val preferencesManager: AppPreferencesManager by lazy { AppPreferencesManager(this) }
  val khataRepository: KhataRepository by lazy { KhataRepository(this, database) }
  val backupRepository: BackupRepository by lazy {
    BackupRepository(this, database, preferencesManager)
  }
  val pdfGenerator: PdfGenerator by lazy { PdfGenerator(this) }

  override fun onCreate() {
    super.onCreate()
    appScope.launch {
      AraafDatabase.seedInitialTractorAndDevice(database)
      khataRepository.purgeExpiredRecycleBin()
    }
  }
}
