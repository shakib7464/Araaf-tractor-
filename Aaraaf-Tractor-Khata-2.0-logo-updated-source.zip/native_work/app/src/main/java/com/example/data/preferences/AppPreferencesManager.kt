package com.example.data.preferences

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.local.entity.LandUnit
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "araaf_khata_prefs")

enum class AppLanguage(val code: String, val displayName: String) {
  BENGALI("bn", "বাংলা"),
  ENGLISH("en", "English"),
}

enum class AppThemeMode(val code: String) {
  SYSTEM("SYSTEM"),
  LIGHT("LIGHT"),
  DARK("DARK"),
}

data class AppSettingsState(
  val language: AppLanguage = AppLanguage.BENGALI,
  val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
  val currencySymbol: String = "৳",
  val dateFormatPattern: String = "dd-MM-yyyy",
  val defaultLandUnit: String = LandUnit.KATHA.code,
  val defaultRatePerDecimal: Double = 35.0,
  val defaultRatePerBigha: Double = 1150.0,
  val defaultRatePerAcre: Double = 3500.0,
  val defaultRatePerHour: Double = 1200.0,
  val pinLockEnabled: Boolean = false,
  val biometricEnabled: Boolean = false,
  val autoDriveBackupEnabled: Boolean = false,
  val wifiOnlyBackup: Boolean = true,
  val driveAccountEmail: String? = null,
  val lastSuccessfulBackupMillis: Long? = null,
  val backupEncryptionPassphraseSet: Boolean = false,
)

class AppPreferencesManager(private val context: Context) {

  private object Keys {
    val LANGUAGE = stringPreferencesKey("language")
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
    val DATE_FORMAT = stringPreferencesKey("date_format")
    val DEFAULT_UNIT = stringPreferencesKey("default_unit")
    val RATE_DECIMAL = doublePreferencesKey("rate_decimal")
    val RATE_BIGHA = doublePreferencesKey("rate_bigha")
    val RATE_ACRE = doublePreferencesKey("rate_acre")
    val RATE_HOUR = doublePreferencesKey("rate_hour")
    val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
    val PIN_HASH = stringPreferencesKey("pin_hash")
    val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
    val AUTO_BACKUP = booleanPreferencesKey("auto_backup")
    val WIFI_ONLY = booleanPreferencesKey("wifi_only")
    val DRIVE_EMAIL = stringPreferencesKey("drive_email")
    val DRIVE_TOKEN_ENC = stringPreferencesKey("drive_token_enc")
    val LAST_BACKUP_AT = longPreferencesKey("last_backup_at")
    val BACKUP_ENC_HASH = stringPreferencesKey("backup_enc_hash")
  }

  val settingsFlow: Flow<AppSettingsState> = context.dataStore.data.map { prefs ->
    AppSettingsState(
      language = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] } ?: AppLanguage.BENGALI,
      themeMode = AppThemeMode.entries.firstOrNull { it.code == prefs[Keys.THEME_MODE] } ?: AppThemeMode.SYSTEM,
      currencySymbol = prefs[Keys.CURRENCY_SYMBOL] ?: "৳",
      dateFormatPattern = prefs[Keys.DATE_FORMAT] ?: "dd-MM-yyyy",
      defaultLandUnit = LandUnit.KATHA.code,
      defaultRatePerDecimal = prefs[Keys.RATE_DECIMAL] ?: 35.0,
      defaultRatePerBigha = prefs[Keys.RATE_BIGHA] ?: 1150.0,
      defaultRatePerAcre = prefs[Keys.RATE_ACRE] ?: 3500.0,
      defaultRatePerHour = prefs[Keys.RATE_HOUR] ?: 1200.0,
      pinLockEnabled = prefs[Keys.PIN_ENABLED] ?: false,
      biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
      autoDriveBackupEnabled = prefs[Keys.AUTO_BACKUP] ?: false,
      wifiOnlyBackup = prefs[Keys.WIFI_ONLY] ?: true,
      driveAccountEmail = prefs[Keys.DRIVE_EMAIL],
      lastSuccessfulBackupMillis = prefs[Keys.LAST_BACKUP_AT],
      backupEncryptionPassphraseSet = !prefs[Keys.BACKUP_ENC_HASH].isNullOrBlank(),
    )
  }

  suspend fun getSettingsNow(): AppSettingsState = settingsFlow.first()

  suspend fun setLanguage(language: AppLanguage) {
    context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
  }

  suspend fun setThemeMode(mode: AppThemeMode) {
    context.dataStore.edit { it[Keys.THEME_MODE] = mode.code }
  }

  suspend fun setDefaultLandUnit(unitCode: String) {
    context.dataStore.edit { it[Keys.DEFAULT_UNIT] = unitCode }
  }

  suspend fun updateDefaultRates(
    perDecimal: Double,
    perBigha: Double,
    perAcre: Double,
    perHour: Double,
  ) {
    context.dataStore.edit {
      it[Keys.RATE_DECIMAL] = perDecimal.coerceAtLeast(0.0)
      it[Keys.RATE_BIGHA] = perBigha.coerceAtLeast(0.0)
      it[Keys.RATE_ACRE] = perAcre.coerceAtLeast(0.0)
      it[Keys.RATE_HOUR] = perHour.coerceAtLeast(0.0)
    }
  }

  suspend fun setCurrencyAndDateFormat(symbol: String, dateFormat: String) {
    context.dataStore.edit {
      it[Keys.CURRENCY_SYMBOL] = symbol.ifBlank { "৳" }
      it[Keys.DATE_FORMAT] = dateFormat.ifBlank { "dd-MM-yyyy" }
    }
  }

  suspend fun setPin(pin: String) {
    val hash = sha256(pin)
    context.dataStore.edit {
      it[Keys.PIN_HASH] = hash
      it[Keys.PIN_ENABLED] = true
    }
  }

  suspend fun disablePin() {
    context.dataStore.edit {
      it.remove(Keys.PIN_HASH)
      it[Keys.PIN_ENABLED] = false
      it[Keys.BIOMETRIC_ENABLED] = false
    }
  }

  suspend fun verifyPin(pin: String): Boolean {
    val stored = context.dataStore.data.first()[Keys.PIN_HASH] ?: return true
    return stored == sha256(pin)
  }

  suspend fun setBiometricEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
  }

  suspend fun setAutoBackupConfig(autoEnabled: Boolean, wifiOnly: Boolean) {
    context.dataStore.edit {
      it[Keys.AUTO_BACKUP] = autoEnabled
      it[Keys.WIFI_ONLY] = wifiOnly
    }
  }

  suspend fun setDriveSession(email: String?, accessToken: String?) {
    context.dataStore.edit { prefs ->
      if (email == null) {
        prefs.remove(Keys.DRIVE_EMAIL)
        prefs.remove(Keys.DRIVE_TOKEN_ENC)
      } else {
        prefs[Keys.DRIVE_EMAIL] = email
        if (!accessToken.isNullOrBlank()) {
          prefs[Keys.DRIVE_TOKEN_ENC] = KeystoreCrypto.encryptString(accessToken)
        }
      }
    }
  }

  suspend fun getDriveAccessToken(): String? {
    val enc = context.dataStore.data.first()[Keys.DRIVE_TOKEN_ENC] ?: return null
    return KeystoreCrypto.decryptString(enc)
  }

  suspend fun setLastBackupTimestamp(millis: Long) {
    context.dataStore.edit { it[Keys.LAST_BACKUP_AT] = millis }
  }

  private fun sha256(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }
}

object KeystoreCrypto {
  private const val KEY_ALIAS = "araaf_khata_token_key"
  private const val ANDROID_KEYSTORE = "AndroidKeyStore"
  private const val TRANSFORMATION = "AES/GCM/NoPadding"

  private fun getOrCreateKey(): SecretKey? {
    return try {
      val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
      (ks.getKey(KEY_ALIAS, null) as? SecretKey) ?: run {
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        gen.init(
          KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
          )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        )
        gen.generateKey()
      }
    } catch (_: Throwable) {
      null
    }
  }

  fun encryptString(plainText: String): String {
    val key = getOrCreateKey() ?: return Base64.encodeToString(plainText.toByteArray(), Base64.NO_WRAP)
    val cipher = Cipher.getInstance(TRANSFORMATION)
    cipher.init(Cipher.ENCRYPT_MODE, key)
    val iv = cipher.iv
    val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
    val combined = ByteArray(1 + iv.size + encrypted.size)
    combined[0] = iv.size.toByte()
    System.arraycopy(iv, 0, combined, 1, iv.size)
    System.arraycopy(encrypted, 0, combined, 1 + iv.size, encrypted.size)
    return "KS1:" + Base64.encodeToString(combined, Base64.NO_WRAP)
  }

  fun decryptString(encoded: String): String? {
    return try {
      if (!encoded.startsWith("KS1:")) {
        return String(Base64.decode(encoded, Base64.NO_WRAP), Charsets.UTF_8)
      }
      val key = getOrCreateKey() ?: return null
      val data = Base64.decode(encoded.removePrefix("KS1:"), Base64.NO_WRAP)
      val ivLen = data[0].toInt() and 0xFF
      val iv = data.copyOfRange(1, 1 + ivLen)
      val ciphertext = data.copyOfRange(1 + ivLen, data.size)
      val cipher = Cipher.getInstance(TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
      String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    } catch (_: Throwable) {
      null
    }
  }
}
