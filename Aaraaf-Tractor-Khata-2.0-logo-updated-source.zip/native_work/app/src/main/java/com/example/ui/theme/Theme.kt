package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class LedgerSemanticColors(
  val dueColor: Color,
  val paidColor: Color,
  val advanceColor: Color,
)

val LocalLedgerColors = staticCompositionLocalOf {
  LedgerSemanticColors(
    dueColor = DueCrimsonLight,
    paidColor = PaidEmeraldLight,
    advanceColor = AdvanceBlueLight,
  )
}

private val LightColorScheme = lightColorScheme(
  primary = EmeraldPrimary,
  onPrimary = EmeraldOnPrimary,
  primaryContainer = EmeraldPrimaryContainer,
  onPrimaryContainer = EmeraldOnPrimaryContainer,
  secondary = AmberSecondary,
  onSecondary = AmberOnSecondary,
  secondaryContainer = AmberSecondaryContainer,
  onSecondaryContainer = AmberOnSecondaryContainer,
  tertiary = TealTertiary,
  onTertiary = TealOnTertiary,
  tertiaryContainer = TealTertiaryContainer,
  onTertiaryContainer = TealOnTertiaryContainer,
  background = WarmBackgroundLight,
  onBackground = TextPrimaryLight,
  surface = WarmSurfaceLight,
  onSurface = TextPrimaryLight,
  surfaceVariant = WarmSurfaceVariantLight,
  onSurfaceVariant = TextSecondaryLight,
  outline = WarmOutlineLight,
  error = DueCrimsonLight,
)

private val DarkColorScheme = darkColorScheme(
  primary = EmeraldPrimaryDark,
  onPrimary = EmeraldOnPrimaryDark,
  primaryContainer = EmeraldPrimaryContainerDark,
  onPrimaryContainer = EmeraldOnPrimaryContainerDark,
  secondary = AmberSecondaryDark,
  onSecondary = AmberOnSecondaryDark,
  secondaryContainer = AmberSecondaryContainerDark,
  onSecondaryContainer = AmberOnSecondaryContainerDark,
  tertiary = TealTertiaryDark,
  onTertiary = TealOnTertiaryDark,
  tertiaryContainer = TealTertiaryContainerDark,
  onTertiaryContainer = TealOnTertiaryContainerDark,
  background = PineBackgroundDark,
  onBackground = TextPrimaryDark,
  surface = PineSurfaceDark,
  onSurface = TextPrimaryDark,
  surfaceVariant = PineSurfaceVariantDark,
  onSurfaceVariant = TextSecondaryDark,
  outline = PineOutlineDark,
  error = DueCrimsonDark,
)

val AppShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp),
)

@Composable
fun AraafKhataTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  val semanticColors = if (darkTheme) {
    LedgerSemanticColors(
      dueColor = DueCrimsonDark,
      paidColor = PaidEmeraldDark,
      advanceColor = AdvanceBlueDark,
    )
  } else {
    LedgerSemanticColors(
      dueColor = DueCrimsonLight,
      paidColor = PaidEmeraldLight,
      advanceColor = AdvanceBlueLight,
    )
  }

  CompositionLocalProvider(LocalLedgerColors provides semanticColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = AppTypography,
      shapes = AppShapes,
      content = content,
    )
  }
}
