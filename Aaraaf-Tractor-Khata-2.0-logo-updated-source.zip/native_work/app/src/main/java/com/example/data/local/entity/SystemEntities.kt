package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
  tableName = "attachments",
  indices = [Index(value = ["ownerType", "ownerId"]), Index(value = ["isDeleted"])],
)
data class AttachmentEntity(
  @PrimaryKey val id: String,
  val ownerType: String,
  val ownerId: String,
  val fileName: String,
  val localPath: String,
  val mimeType: String,
  val fileSizeBytes: Long = 0L,
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
)

@Serializable
@Entity(
  tableName = "audit_logs",
  indices = [Index(value = ["entityType", "entityId"]), Index(value = ["timestamp"])],
)
data class AuditLogEntity(
  @PrimaryKey val id: String,
  val entityType: String,
  val entityId: String,
  val action: String,
  val summary: String,
  val previousValueJson: String? = null,
  val newValueJson: String? = null,
  val timestamp: Long,
  val deviceId: String,
)

@Serializable
@Entity(
  tableName = "backup_history",
  indices = [Index(value = ["createdAt"]), Index(value = ["status"])],
)
data class BackupHistoryEntity(
  @PrimaryKey val id: String,
  val fileName: String,
  val driveFileId: String? = null,
  val localFilePath: String? = null,
  val backupType: String,
  val status: String,
  val recordCount: Int = 0,
  val attachmentCount: Int = 0,
  val fileSizeBytes: Long = 0L,
  val checksumSha256: String = "",
  val isEncrypted: Boolean = false,
  val errorMessage: String? = null,
  val createdAt: Long,
  val verifiedAt: Long? = null,
)

@Serializable
@Entity(
  tableName = "sync_queue",
  indices = [Index(value = ["status"]), Index(value = ["entityType", "entityId"])],
)
data class SyncQueueEntity(
  @PrimaryKey val id: String,
  val entityType: String,
  val entityId: String,
  val operation: String,
  val payloadJson: String,
  val status: String = SyncStatus.PENDING_SYNC.code,
  val retryCount: Int = 0,
  val lastError: String? = null,
  val createdAt: Long,
  val updatedAt: Long,
)

@Serializable
@Entity(tableName = "device_information")
data class DeviceInformationEntity(
  @PrimaryKey val deviceId: String,
  val deviceName: String,
  val appVersion: String,
  val lastSyncAt: Long? = null,
  val lastBackupAt: Long? = null,
  val updatedAt: Long,
)
