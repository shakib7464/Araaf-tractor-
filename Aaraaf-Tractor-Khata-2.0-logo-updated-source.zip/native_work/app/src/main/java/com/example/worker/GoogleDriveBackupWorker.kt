package com.example.worker

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.backup.BackupRepository
import com.example.data.local.AraafDatabase
import com.example.data.preferences.AppPreferencesManager
import java.util.concurrent.TimeUnit

class GoogleDriveBackupWorker(
  appContext: Context,
  workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

  override suspend fun doWork(): Result {
    val db = AraafDatabase.getInstance(applicationContext)
    val prefs = AppPreferencesManager(applicationContext)
    val repo = BackupRepository(applicationContext, db, prefs)

    val settings = prefs.getSettingsNow()
    if (settings.driveAccountEmail.isNullOrBlank()) {
      return Result.success()
    }

    val backupResult = repo.performGoogleDriveBackup()
    return if (backupResult.isSuccess) {
      Result.success()
    } else {
      if (runAttemptCount < 5) Result.retry() else Result.failure()
    }
  }

  companion object {
    private const val UNIQUE_PERIODIC_NAME = "araaf_drive_periodic_backup"
    private const val UNIQUE_PENDING_NAME = "araaf_drive_pending_backup"

    fun scheduleAutoBackup(context: Context, enabled: Boolean, wifiOnly: Boolean) {
      val wm = WorkManager.getInstance(context)
      if (!enabled) {
        wm.cancelUniqueWork(UNIQUE_PERIODIC_NAME)
        return
      }
      val constraints = Constraints.Builder()
        .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true)
        .build()

      val request = PeriodicWorkRequestBuilder<GoogleDriveBackupWorker>(12, TimeUnit.HOURS)
        .setConstraints(constraints)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
        .build()

      wm.enqueueUniquePeriodicWork(
        UNIQUE_PERIODIC_NAME,
        ExistingPeriodicWorkPolicy.UPDATE,
        request,
      )
    }

    fun enqueueOneTimeWhenOnline(context: Context, wifiOnly: Boolean) {
      val constraints = Constraints.Builder()
        .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
        .build()

      val request = OneTimeWorkRequestBuilder<GoogleDriveBackupWorker>()
        .setConstraints(constraints)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 5, TimeUnit.MINUTES)
        .build()

      WorkManager.getInstance(context).enqueueUniqueWork(
        UNIQUE_PENDING_NAME,
        ExistingWorkPolicy.REPLACE,
        request,
      )
    }
  }
}
