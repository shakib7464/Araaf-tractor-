package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings
import com.example.ui.components.AttachmentSection
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
  summary: CustomerFinancialSummary,
  attachments: List<AttachmentEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onEditCustomer: () -> Unit,
  onDeleteCustomer: () -> Unit,
  onAddLand: () -> Unit,
  onSelectLand: (String) -> Unit,
  onAddJob: () -> Unit,
  onReceivePayment: () -> Unit,
  onPrintCustomerStatement: () -> Unit,
  onPrintPaymentReceipt: (PaymentEntity) -> Unit,
  onAddAttachment: (Uri) -> Unit,
  onDeleteAttachment: (String) -> Unit,
) {
  val c = summary.customer
  val ledgerColors = LocalLedgerColors.current
  var selectedTab by remember { mutableIntStateOf(0) }
  var confirmDelete by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("${c.fullName} (${c.customerCode})") },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("customer_detail_back")) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          IconButton(onClick = onPrintCustomerStatement, modifier = Modifier.testTag("customer_print_btn")) {
            Icon(Icons.Rounded.Print, contentDescription = strings.printCustomerStatement)
          }
          IconButton(onClick = onEditCustomer) {
            Icon(Icons.Rounded.Edit, contentDescription = strings.edit)
          }
          IconButton(onClick = { confirmDelete = true }) {
            Icon(Icons.Rounded.DeleteOutline, contentDescription = strings.delete)
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Customer Info + Financial Summary Card
      item {
        Card(
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${c.mobileNumber} • ${listOf(c.village, c.unionName, c.upazila, c.district).filter { it.isNotBlank() }.joinToString(", ")}")
            if (c.address.isNotBlank()) {
              Text(c.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
              "${strings.registrationDate}: ${FormatUtils.formatDate(c.registrationDate)}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              SummaryPill(
                label = strings.totalBilled,
                value = FormatUtils.formatTaka(summary.totalBilled, currencySymbol),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f),
              )
              SummaryPill(
                label = strings.totalCollected,
                value = FormatUtils.formatTaka(summary.totalPaid, currencySymbol),
                color = ledgerColors.paidColor,
                modifier = Modifier.weight(1f),
              )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              SummaryPill(
                label = strings.totalOutstanding,
                value = FormatUtils.formatTaka(summary.totalOutstandingBalance, currencySymbol),
                color = ledgerColors.dueColor,
                modifier = Modifier.weight(1f),
              )
              SummaryPill(
                label = strings.remainingAdvance,
                value = FormatUtils.formatTaka(summary.remainingAdvance, currencySymbol),
                color = ledgerColors.advanceColor,
                modifier = Modifier.weight(1f),
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = onPrintCustomerStatement,
                modifier = Modifier.weight(1f).height(48.dp).testTag("customer_statement_pdf_btn"),
              ) {
                Icon(Icons.Rounded.Print, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(strings.printCustomerStatement, maxLines = 1)
              }
              FilledTonalButton(
                onClick = onReceivePayment,
                modifier = Modifier.weight(1f).height(48.dp),
              ) {
                Icon(Icons.Rounded.Payments, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(strings.receivePayment, maxLines = 1)
              }
            }
          }
        }
      }

      // Attachments
      item {
        AttachmentSection(
          title = strings.attachmentsTitle,
          attachments = attachments,
          onAddAttachmentUri = onAddAttachment,
          onDeleteAttachment = onDeleteAttachment,
        )
      }

      // Tabs: Lands | Jobs | Payments | Advances
      item {
        TabRow(selectedTabIndex = selectedTab) {
          Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("${strings.landsOwned} (${summary.lands.size})") })
          Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("${strings.jobsHistory} (${summary.jobs.size})") })
          Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("${strings.paymentsHistory} (${summary.payments.size})") })
          Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text(strings.advanceLedger) })
        }
      }

      when (selectedTab) {
        0 -> {
          item {
            OutlinedButton(
              onClick = onAddLand,
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("customer_add_land_btn"),
            ) {
              Icon(Icons.Rounded.Add, contentDescription = null)
              Spacer(Modifier.width(6.dp))
              Text(strings.addLand)
            }
          }
          if (summary.lands.isEmpty()) {
            item {
              EmptyStateCard(
                icon = Icons.Rounded.Landscape,
                message = "এই কাস্টমারের এখনো কোনো জমি নিবন্ধিত নেই",
                actionLabel = strings.addLand,
                onAction = onAddLand,
              )
            }
          } else {
            items(summary.lands, key = { it.land.id }) { ls ->
              Card(
                onClick = { onSelectLand(ls.land.id) },
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth().testTag("land_card_${ls.land.landCode}"),
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text("${ls.land.landName} (${ls.land.landCode})", fontWeight = FontWeight.Bold)
                    Text(
                      "${FormatUtils.formatNumber(ls.land.sizeValue)} ${strings.unitLabel(ls.land.unit)} • ${ls.jobs.size} কাজ",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text("আলাদা খতিয়ান বকেয়া", style = MaterialTheme.typography.labelSmall)
                    Text(
                      FormatUtils.formatTaka(ls.currentBalance, currencySymbol),
                      fontWeight = FontWeight.Bold,
                      color = if (ls.currentBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                    )
                  }
                }
              }
            }
          }
        }
        1 -> {
          item {
            OutlinedButton(
              onClick = onAddJob,
              modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
              Icon(Icons.Rounded.Add, contentDescription = null)
              Spacer(Modifier.width(6.dp))
              Text(strings.addJob)
            }
          }
          items(summary.jobs, key = { it.id }) { j ->
            val landName = summary.lands.firstOrNull { it.land.id == j.landId }?.land?.landName ?: "-"
            Surface(
              shape = MaterialTheme.shapes.medium,
              tonalElevation = 1.dp,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("${j.jobCode} • ${strings.workTypeLabel(j.workType, j.customWorkName)}", fontWeight = FontWeight.SemiBold)
                  Text("$landName • ${FormatUtils.formatDate(j.workDate)}", style = MaterialTheme.typography.bodySmall)
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(FormatUtils.formatTaka(j.totalBill, currencySymbol), fontWeight = FontWeight.Bold)
                  Text(strings.jobStatusLabel(j.status), style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
        2 -> {
          items(summary.payments, key = { it.id }) { p ->
            val landName = summary.lands.firstOrNull { it.land.id == p.landId }?.land?.landName ?: "-"
            Surface(
              shape = MaterialTheme.shapes.medium,
              tonalElevation = 1.dp,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("${p.receiptNumber} (${strings.paymentMethodLabel(p.paymentMethod)})", fontWeight = FontWeight.SemiBold)
                  Text("$landName • ${FormatUtils.formatDate(p.paymentDate)}", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    FormatUtils.formatTaka(p.amount, currencySymbol),
                    fontWeight = FontWeight.Bold,
                    color = ledgerColors.paidColor,
                  )
                  IconButton(onClick = { onPrintPaymentReceipt(p) }) {
                    Icon(Icons.Rounded.Receipt, contentDescription = strings.generateReceiptPdf)
                  }
                }
              }
            }
          }
        }
        3 -> {
          item {
            Surface(
              shape = MaterialTheme.shapes.medium,
              color = ledgerColors.advanceColor.copy(alpha = 0.1f),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${strings.totalAdvanceReceived}: ${FormatUtils.formatTaka(summary.totalAdvanceReceived, currencySymbol)}")
                Text("${strings.totalAdvanceUsed}: ${FormatUtils.formatTaka(summary.totalAdvanceUsed, currencySymbol)}")
                Text(
                  "${strings.remainingAdvance}: ${FormatUtils.formatTaka(summary.remainingAdvance, currencySymbol)}",
                  fontWeight = FontWeight.Bold,
                  color = ledgerColors.advanceColor,
                )
              }
            }
          }
          items(summary.advanceEntries, key = { it.id }) { adv ->
            Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
              Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                  Text("${adv.receiptNumber} • ${strings.advanceTypeLabel(adv.entryType)}", fontWeight = FontWeight.SemiBold)
                  Text(FormatUtils.formatDate(adv.transactionDate), style = MaterialTheme.typography.bodySmall)
                }
                Text(FormatUtils.formatTaka(adv.amount, currencySymbol), fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }

  if (confirmDelete) {
    AlertDialog(
      onDismissRequest = { confirmDelete = false },
      title = { Text("কাস্টমার মুছবেন?") },
      text = { Text("${c.fullName} এবং সংযুক্ত তথ্য ৩০ দিনের জন্য রিসাইকেল বিনে পাঠানো হবে।") },
      confirmButton = {
        TextButton(onClick = { confirmDelete = false; onDeleteCustomer() }) { Text(strings.confirm) }
      },
      dismissButton = {
        TextButton(onClick = { confirmDelete = false }) { Text(strings.cancel) }
      },
    )
  }
}

@Composable
private fun SummaryPill(
  label: String,
  value: String,
  color: androidx.compose.ui.graphics.Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = MaterialTheme.shapes.small,
    color = color.copy(alpha = 0.1f),
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
    }
  }
}
