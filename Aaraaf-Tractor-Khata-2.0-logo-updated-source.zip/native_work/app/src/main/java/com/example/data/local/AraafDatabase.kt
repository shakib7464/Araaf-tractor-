package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AdvancePaymentDao
import com.example.data.local.dao.AgriculturalJobDao
import com.example.data.local.dao.AttachmentDao
import com.example.data.local.dao.AuditLogDao
import com.example.data.local.dao.BackupHistoryDao
import com.example.data.local.dao.CustomerDao
import com.example.data.local.dao.DeviceInfoDao
import com.example.data.local.dao.LandDao
import com.example.data.local.dao.LandRateHistoryDao
import com.example.data.local.dao.LedgerTransactionDao
import com.example.data.local.dao.PaymentDao
import com.example.data.local.dao.SyncQueueDao
import com.example.data.local.dao.TractorDao
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.DeviceInformationEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandRateHistoryEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.SyncQueueEntity
import com.example.data.local.entity.TractorEntity
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    CustomerEntity::class,
    LandEntity::class,
    LandRateHistoryEntity::class,
    TractorEntity::class,
    AgriculturalJobEntity::class,
    PaymentEntity::class,
    AdvancePaymentEntity::class,
    LedgerTransactionEntity::class,
    AttachmentEntity::class,
    AuditLogEntity::class,
    BackupHistoryEntity::class,
    SyncQueueEntity::class,
    DeviceInformationEntity::class,
  ],
  version = 2,
  exportSchema = false,
)
abstract class AraafDatabase : RoomDatabase() {
  abstract fun customerDao(): CustomerDao
  abstract fun landDao(): LandDao
  abstract fun landRateHistoryDao(): LandRateHistoryDao
  abstract fun tractorDao(): TractorDao
  abstract fun jobDao(): AgriculturalJobDao
  abstract fun paymentDao(): PaymentDao
  abstract fun advancePaymentDao(): AdvancePaymentDao
  abstract fun ledgerTransactionDao(): LedgerTransactionDao
  abstract fun attachmentDao(): AttachmentDao
  abstract fun auditLogDao(): AuditLogDao
  abstract fun backupHistoryDao(): BackupHistoryDao
  abstract fun syncQueueDao(): SyncQueueDao
  abstract fun deviceInfoDao(): DeviceInfoDao

  companion object {
    const val DB_NAME = "araaf_tractor_khata.db"

    @Volatile private var INSTANCE: AraafDatabase? = null

    fun getInstance(context: Context): AraafDatabase {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
      }
    }

    private fun buildDatabase(context: Context): AraafDatabase {
      return Room.databaseBuilder(context, AraafDatabase::class.java, DB_NAME)
        .fallbackToDestructiveMigration(dropAllTables = true)
        .addCallback(
          object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              CoroutineScope(Dispatchers.IO).launch {
                seedInitialTractorAndDevice(getInstance(context))
              }
            }
          }
        )
        .build()
    }

    suspend fun seedInitialTractorAndDevice(database: AraafDatabase) {
      val now = System.currentTimeMillis()
      val existingDevice = database.deviceInfoDao().getDeviceInfoNow()
      val deviceId = existingDevice?.deviceId ?: UUID.randomUUID().toString()
      if (existingDevice == null) {
        database.deviceInfoDao().upsert(
          DeviceInformationEntity(
            deviceId = deviceId,
            deviceName = android.os.Build.MODEL ?: "Android Device",
            appVersion = "1.0",
            updatedAt = now,
          )
        )
      }
      if (database.tractorDao().getActiveCount() == 0) {
        database.tractorDao().insert(
          TractorEntity(
            id = UUID.randomUUID().toString(),
            tractorCode = "TRC-01",
            name = "আরাফ ট্রাক্টর-০১",
            brand = "Mahindra / Sonalika",
            model = "575 DI",
            registrationInfo = "প্রাথমিক নিবন্ধিত ট্রাক্টর",
            notes = "ডিফল্ট ট্রাক্টর",
            isActive = true,
            createdAt = now,
            updatedAt = now,
            deviceId = deviceId,
          )
        )
      }
    }
  }
}
