package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
  tableName = "agricultural_jobs",
  foreignKeys = [
    ForeignKey(
      entity = CustomerEntity::class,
      parentColumns = ["id"],
      childColumns = ["customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = LandEntity::class,
      parentColumns = ["id", "customerId"],
      childColumns = ["landId", "customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = TractorEntity::class,
      parentColumns = ["id"],
      childColumns = ["tractorId"],
      onDelete = ForeignKey.SET_NULL,
    ),
  ],
  indices = [
    Index(value = ["customerId"]),
    Index(value = ["landId"]),
    Index(value = ["landId", "customerId"]),
    Index(value = ["tractorId"]),
    Index(value = ["workDate"]),
    Index(value = ["status"]),
    Index(value = ["isDeleted"]),
  ],
)
data class AgriculturalJobEntity(
  @PrimaryKey val id: String,
  val jobCode: String,
  val customerId: String,
  val landId: String,
  val tractorId: String? = null,
  val workDate: Long,
  val workType: String = WorkType.ROTAVATOR.code,
  val customWorkName: String = "",
  val billingMethod: String = BillingMethod.PER_DECIMAL.code,
  val landArea: Double,
  val areaUnit: String = LandUnit.DECIMAL.code,
  val rate: Double,
  val workingHours: Double? = null,
  val baseBill: Double,
  val additionalCharges: Double = 0.0,
  val discount: Double = 0.0,
  val totalBill: Double,
  val advanceAdjustment: Double = 0.0,
  val amountPaid: Double = 0.0,
  val remainingDue: Double = 0.0,
  val status: String = JobStatus.COMPLETED.code,
  val rotavatorWidth: String = "",
  val workingDepth: String = "",
  val numberOfPasses: Int? = null,
  val startTime: String = "",
  val finishTime: String = "",
  val operatorName: String = "",
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)

@Serializable
@Entity(
  tableName = "payments",
  foreignKeys = [
    ForeignKey(
      entity = CustomerEntity::class,
      parentColumns = ["id"],
      childColumns = ["customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = LandEntity::class,
      parentColumns = ["id", "customerId"],
      childColumns = ["landId", "customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = AgriculturalJobEntity::class,
      parentColumns = ["id"],
      childColumns = ["jobId"],
      onDelete = ForeignKey.SET_NULL,
    ),
  ],
  indices = [
    Index(value = ["customerId"]),
    Index(value = ["landId"]),
    Index(value = ["landId", "customerId"]),
    Index(value = ["jobId"]),
    Index(value = ["paymentDate"]),
    Index(value = ["isDeleted"]),
  ],
)
data class PaymentEntity(
  @PrimaryKey val id: String,
  val receiptNumber: String,
  val customerId: String,
  val landId: String,
  val jobId: String? = null,
  val targetType: String = PaymentTargetType.LAND.code,
  val paymentDate: Long,
  val amount: Double,
  val paymentMethod: String = PaymentMethod.CASH.code,
  val previousBalanceSnapshot: Double = 0.0,
  val remainingBalanceSnapshot: Double = 0.0,
  val referenceNote: String = "",
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)

@Serializable
@Entity(
  tableName = "advance_payments",
  foreignKeys = [
    ForeignKey(
      entity = CustomerEntity::class,
      parentColumns = ["id"],
      childColumns = ["customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = LandEntity::class,
      parentColumns = ["id"],
      childColumns = ["landId"],
      onDelete = ForeignKey.SET_NULL,
    ),
    ForeignKey(
      entity = AgriculturalJobEntity::class,
      parentColumns = ["id"],
      childColumns = ["jobId"],
      onDelete = ForeignKey.SET_NULL,
    ),
  ],
  indices = [
    Index(value = ["customerId"]),
    Index(value = ["landId"]),
    Index(value = ["jobId"]),
    Index(value = ["transactionDate"]),
    Index(value = ["isDeleted"]),
  ],
)
data class AdvancePaymentEntity(
  @PrimaryKey val id: String,
  val receiptNumber: String,
  val customerId: String,
  val landId: String? = null,
  val jobId: String? = null,
  val entryType: String = AdvanceEntryType.RECEIVED.code,
  val amount: Double,
  val paymentMethod: String = PaymentMethod.CASH.code,
  val transactionDate: Long,
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)

@Serializable
@Entity(
  tableName = "ledger_transactions",
  foreignKeys = [
    ForeignKey(
      entity = CustomerEntity::class,
      parentColumns = ["id"],
      childColumns = ["customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = LandEntity::class,
      parentColumns = ["id", "customerId"],
      childColumns = ["landId", "customerId"],
      onDelete = ForeignKey.RESTRICT,
    ),
    ForeignKey(
      entity = AgriculturalJobEntity::class,
      parentColumns = ["id"],
      childColumns = ["jobId"],
      onDelete = ForeignKey.SET_NULL,
    ),
    ForeignKey(
      entity = PaymentEntity::class,
      parentColumns = ["id"],
      childColumns = ["paymentId"],
      onDelete = ForeignKey.SET_NULL,
    ),
    ForeignKey(
      entity = AdvancePaymentEntity::class,
      parentColumns = ["id"],
      childColumns = ["advanceId"],
      onDelete = ForeignKey.SET_NULL,
    ),
  ],
  indices = [
    Index(value = ["customerId"]),
    Index(value = ["landId"]),
    Index(value = ["landId", "customerId"]),
    Index(value = ["jobId"]),
    Index(value = ["paymentId"]),
    Index(value = ["advanceId"]),
    Index(value = ["transactionDate"]),
    Index(value = ["isDeleted"]),
  ],
)
data class LedgerTransactionEntity(
  @PrimaryKey val id: String,
  val transactionCode: String,
  val customerId: String,
  val landId: String,
  val jobId: String? = null,
  val paymentId: String? = null,
  val advanceId: String? = null,
  val transactionDate: Long,
  val transactionType: String,
  val debitAmount: Double = 0.0,
  val creditAmount: Double = 0.0,
  val description: String,
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)
