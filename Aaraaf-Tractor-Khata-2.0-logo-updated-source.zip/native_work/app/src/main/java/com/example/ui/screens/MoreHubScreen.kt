package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppStrings

data class MoreMenuItem(
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val tag: String,
  val onClick: () -> Unit,
)

@Composable
fun MoreHubScreen(
  strings: AppStrings,
  tractorCount: Int,
  trashCount: Int,
  lastBackupText: String,
  onReceivePayment: () -> Unit,
  onOpenTractors: () -> Unit,
  onOpenBackup: () -> Unit,
  onOpenRecycleBin: () -> Unit,
  onOpenAuditLog: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val items = listOf(
    MoreMenuItem(
      title = "${strings.receivePayment} / ${strings.receiveAdvance}",
      subtitle = "নগদ, ব্যাংক, বিকাশ, নগদ ও অগ্রিম সমন্বয়",
      icon = Icons.Rounded.Payments,
      tag = "more_payments",
      onClick = onReceivePayment,
    ),
    MoreMenuItem(
      title = strings.tractorsTitle,
      subtitle = "$tractorCount টি নিবন্ধিত ট্রাক্টর (মাল্টি-ট্রাক্টর প্রস্তুত)",
      icon = Icons.Rounded.Agriculture,
      tag = "more_tractors",
      onClick = onOpenTractors,
    ),
    MoreMenuItem(
      title = strings.backupRestoreTitle,
      subtitle = lastBackupText,
      icon = Icons.Rounded.CloudUpload,
      tag = "more_backup",
      onClick = onOpenBackup,
    ),
    MoreMenuItem(
      title = strings.recycleBinTitle,
      subtitle = "$trashCount টি পুনরুদ্ধারযোগ্য রেকর্ড (৩০ দিন)",
      icon = Icons.Rounded.DeleteSweep,
      tag = "more_recycle_bin",
      onClick = onOpenRecycleBin,
    ),
    MoreMenuItem(
      title = strings.auditLogTitle,
      subtitle = "সকল পরিবর্তন, পেমেন্ট ও রিস্টোরের ইতিহাস",
      icon = Icons.Rounded.History,
      tag = "more_audit_log",
      onClick = onOpenAuditLog,
    ),
    MoreMenuItem(
      title = strings.settingsTitle,
      subtitle = "ভাষা, থিম, ডিফল্ট রেট, পিন ও ফিঙ্গারপ্রিন্ট লক",
      icon = Icons.Rounded.Settings,
      tag = "more_settings",
      onClick = onOpenSettings,
    ),
  )

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Text(
        "Araaf Tractor Khata — ব্যবস্থাপনা",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 4.dp),
      )
    }
    items(items, key = { it.tag }) { item ->
      Card(
        onClick = item.onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth().testTag(item.tag),
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          Icon(
            item.icon,
            contentDescription = item.title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp),
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null)
        }
      }
    }
  }
}
