package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AgriculturalJobDao {
  @Query("SELECT * FROM agricultural_jobs WHERE isDeleted = 0 ORDER BY workDate DESC, createdAt DESC")
  fun observeActiveJobs(): Flow<List<AgriculturalJobEntity>>

  @Query("SELECT * FROM agricultural_jobs WHERE customerId = :customerId AND isDeleted = 0 ORDER BY workDate DESC, createdAt DESC")
  fun observeJobsByCustomer(customerId: String): Flow<List<AgriculturalJobEntity>>

  @Query("SELECT * FROM agricultural_jobs WHERE landId = :landId AND isDeleted = 0 ORDER BY workDate DESC, createdAt DESC")
  fun observeJobsByLand(landId: String): Flow<List<AgriculturalJobEntity>>

  @Query("SELECT * FROM agricultural_jobs WHERE isDeleted = 1 ORDER BY deletedAt DESC")
  fun observeDeletedJobs(): Flow<List<AgriculturalJobEntity>>

  @Query("SELECT * FROM agricultural_jobs WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): AgriculturalJobEntity?

  @Query("SELECT * FROM agricultural_jobs WHERE isDeleted = 0 ORDER BY workDate DESC, createdAt DESC")
  suspend fun getActiveJobsNow(): List<AgriculturalJobEntity>

  @Query("SELECT * FROM agricultural_jobs")
  suspend fun getAllJobsIncludingDeleted(): List<AgriculturalJobEntity>

  @Query("SELECT COUNT(*) FROM agricultural_jobs")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(job: AgriculturalJobEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(jobs: List<AgriculturalJobEntity>)

  @Update
  suspend fun update(job: AgriculturalJobEntity)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE id = :id"
  )
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE landId = :landId AND isDeleted = 0"
  )
  suspend fun softDeleteByLand(landId: String, deletedAt: Long)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE customerId = :customerId AND isDeleted = 0"
  )
  suspend fun softDeleteByCustomer(customerId: String, deletedAt: Long)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE id = :id"
  )
  suspend fun restore(id: String, now: Long)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE landId = :landId"
  )
  suspend fun restoreByLand(landId: String, now: Long)

  @Query(
    "UPDATE agricultural_jobs SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE customerId = :customerId"
  )
  suspend fun restoreByCustomer(customerId: String, now: Long)

  @Query("DELETE FROM agricultural_jobs WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM agricultural_jobs WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM agricultural_jobs")
  suspend fun deleteAll()
}

@Dao
interface PaymentDao {
  @Query("SELECT * FROM payments WHERE isDeleted = 0 ORDER BY paymentDate DESC, createdAt DESC")
  fun observeActivePayments(): Flow<List<PaymentEntity>>

  @Query("SELECT * FROM payments WHERE customerId = :customerId AND isDeleted = 0 ORDER BY paymentDate DESC, createdAt DESC")
  fun observePaymentsByCustomer(customerId: String): Flow<List<PaymentEntity>>

  @Query("SELECT * FROM payments WHERE landId = :landId AND isDeleted = 0 ORDER BY paymentDate DESC, createdAt DESC")
  fun observePaymentsByLand(landId: String): Flow<List<PaymentEntity>>

  @Query("SELECT * FROM payments WHERE isDeleted = 1 ORDER BY deletedAt DESC")
  fun observeDeletedPayments(): Flow<List<PaymentEntity>>

  @Query("SELECT * FROM payments WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): PaymentEntity?

  @Query("SELECT * FROM payments WHERE isDeleted = 0 ORDER BY paymentDate DESC, createdAt DESC")
  suspend fun getActivePaymentsNow(): List<PaymentEntity>

  @Query("SELECT * FROM payments")
  suspend fun getAllIncludingDeleted(): List<PaymentEntity>

  @Query("SELECT COUNT(*) FROM payments")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(payment: PaymentEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(payments: List<PaymentEntity>)

  @Query("UPDATE payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query("UPDATE payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE jobId = :jobId AND isDeleted = 0")
  suspend fun softDeleteByJob(jobId: String, deletedAt: Long)

  @Query("UPDATE payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE landId = :landId AND isDeleted = 0")
  suspend fun softDeleteByLand(landId: String, deletedAt: Long)

  @Query("UPDATE payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE customerId = :customerId AND isDeleted = 0")
  suspend fun softDeleteByCustomer(customerId: String, deletedAt: Long)

  @Query("UPDATE payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE id = :id")
  suspend fun restore(id: String, now: Long)

  @Query("UPDATE payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE jobId = :jobId")
  suspend fun restoreByJob(jobId: String, now: Long)

  @Query("UPDATE payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE landId = :landId")
  suspend fun restoreByLand(landId: String, now: Long)

  @Query("UPDATE payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE customerId = :customerId")
  suspend fun restoreByCustomer(customerId: String, now: Long)

  @Query("DELETE FROM payments WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM payments WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM payments")
  suspend fun deleteAll()
}

@Dao
interface AdvancePaymentDao {
  @Query("SELECT * FROM advance_payments WHERE isDeleted = 0 ORDER BY transactionDate DESC, createdAt DESC")
  fun observeActiveAdvances(): Flow<List<AdvancePaymentEntity>>

  @Query("SELECT * FROM advance_payments WHERE customerId = :customerId AND isDeleted = 0 ORDER BY transactionDate DESC, createdAt DESC")
  fun observeAdvancesByCustomer(customerId: String): Flow<List<AdvancePaymentEntity>>

  @Query("SELECT * FROM advance_payments WHERE isDeleted = 0 ORDER BY transactionDate DESC, createdAt DESC")
  suspend fun getActiveAdvancesNow(): List<AdvancePaymentEntity>

  @Query("SELECT * FROM advance_payments WHERE customerId = :customerId AND isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  suspend fun getAdvancesByCustomerNow(customerId: String): List<AdvancePaymentEntity>

  @Query("SELECT * FROM advance_payments")
  suspend fun getAllIncludingDeleted(): List<AdvancePaymentEntity>

  @Query("SELECT COUNT(*) FROM advance_payments")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: AdvancePaymentEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(entries: List<AdvancePaymentEntity>)

  @Query("UPDATE advance_payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query("UPDATE advance_payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE jobId = :jobId AND isDeleted = 0")
  suspend fun softDeleteByJob(jobId: String, deletedAt: Long)

  @Query("UPDATE advance_payments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE customerId = :customerId AND isDeleted = 0")
  suspend fun softDeleteByCustomer(customerId: String, deletedAt: Long)

  @Query("UPDATE advance_payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE id = :id")
  suspend fun restore(id: String, now: Long)

  @Query("UPDATE advance_payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE jobId = :jobId")
  suspend fun restoreByJob(jobId: String, now: Long)

  @Query("UPDATE advance_payments SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE customerId = :customerId")
  suspend fun restoreByCustomer(customerId: String, now: Long)

  @Query("DELETE FROM advance_payments WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM advance_payments WHERE customerId = :customerId")
  suspend fun hardDeleteByCustomer(customerId: String)

  @Query("DELETE FROM advance_payments WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM advance_payments")
  suspend fun deleteAll()
}

@Dao
interface LedgerTransactionDao {
  @Query("SELECT * FROM ledger_transactions WHERE isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  fun observeActiveTransactions(): Flow<List<LedgerTransactionEntity>>

  @Query("SELECT * FROM ledger_transactions WHERE landId = :landId AND isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  fun observeTransactionsByLand(landId: String): Flow<List<LedgerTransactionEntity>>

  @Query("SELECT * FROM ledger_transactions WHERE customerId = :customerId AND isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  fun observeTransactionsByCustomer(customerId: String): Flow<List<LedgerTransactionEntity>>

  @Query("SELECT * FROM ledger_transactions WHERE isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  suspend fun getActiveTransactionsNow(): List<LedgerTransactionEntity>

  @Query("SELECT * FROM ledger_transactions WHERE landId = :landId AND isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  suspend fun getTransactionsByLandNow(landId: String): List<LedgerTransactionEntity>

  @Query("SELECT * FROM ledger_transactions WHERE customerId = :customerId AND isDeleted = 0 ORDER BY transactionDate ASC, createdAt ASC")
  suspend fun getTransactionsByCustomerNow(customerId: String): List<LedgerTransactionEntity>

  @Query("SELECT * FROM ledger_transactions")
  suspend fun getAllIncludingDeleted(): List<LedgerTransactionEntity>

  @Query("SELECT COUNT(*) FROM ledger_transactions")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(txn: LedgerTransactionEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(txns: List<LedgerTransactionEntity>)

  @Query("UPDATE ledger_transactions SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE jobId = :jobId AND isDeleted = 0")
  suspend fun softDeleteByJob(jobId: String, deletedAt: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE paymentId = :paymentId AND isDeleted = 0")
  suspend fun softDeleteByPayment(paymentId: String, deletedAt: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE landId = :landId AND isDeleted = 0")
  suspend fun softDeleteByLand(landId: String, deletedAt: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE customerId = :customerId AND isDeleted = 0")
  suspend fun softDeleteByCustomer(customerId: String, deletedAt: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE jobId = :jobId")
  suspend fun restoreByJob(jobId: String, now: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE paymentId = :paymentId")
  suspend fun restoreByPayment(paymentId: String, now: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE landId = :landId")
  suspend fun restoreByLand(landId: String, now: Long)

  @Query("UPDATE ledger_transactions SET isDeleted = 0, deletedAt = NULL, updatedAt = :now WHERE customerId = :customerId")
  suspend fun restoreByCustomer(customerId: String, now: Long)

  @Query("DELETE FROM ledger_transactions WHERE jobId = :jobId")
  suspend fun hardDeleteByJob(jobId: String)

  @Query("DELETE FROM ledger_transactions WHERE customerId = :customerId")
  suspend fun hardDeleteByCustomer(customerId: String)

  @Query("DELETE FROM ledger_transactions WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM ledger_transactions")
  suspend fun deleteAll()
}
