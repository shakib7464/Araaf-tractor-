package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.domain.model.DashboardSummary
import com.example.localization.AppStrings
import com.example.ui.screens.DashboardScreen
import com.example.ui.theme.AraafKhataTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AraafUiCujRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `dashboard displays Araaf Tractor Khata and one-click bulk print button works`() {
    var bulkPrintClicked = false
    val summary = DashboardSummary(
      totalCustomers = 5,
      totalLands = 9,
      totalJobs = 12,
      completedJobs = 10,
      pendingJobs = 2,
      totalBilledAmount = 25000.0,
      totalCollectedAmount = 18000.0,
      totalOutstandingAmount = 7000.0,
      totalAdvanceReceived = 3000.0,
      totalRemainingAdvance = 1500.0,
      todaysJobCount = 2,
      todaysBilledAmount = 3500.0,
      todaysCollectionAmount = 2000.0,
      monthlyBilledAmount = 14000.0,
      monthlyCollectionAmount = 10000.0,
      recentActivities = emptyList(),
    )

    composeTestRule.setContent {
      AraafKhataTheme {
        DashboardScreen(
          summary = summary,
          strings = AppStrings.Bengali,
          currencySymbol = "৳",
          onAddCustomer = {},
          onAddLand = {},
          onAddJob = {},
          onReceivePayment = {},
          onViewOutstandingDues = {},
          onViewReports = {},
          onOneClickBulkPrint = { bulkPrintClicked = true },
          onConfigureBulkPrint = {},
        )
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Araaf Tractor Khata").assertIsDisplayed()
    composeTestRule.onNodeWithText("সব কাস্টমারের হিসাব একসাথে প্রিন্ট").assertIsDisplayed()
    composeTestRule.onNodeWithTag("dashboard_bulk_print_btn").performClick()
    composeTestRule.waitForIdle()
    assertTrue(bulkPrintClicked)
  }
}
